
docker build --tag telegram_consumer .

Per la creazione delle immagini Docker
